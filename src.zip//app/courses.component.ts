import {Component} from '@angular/core'

@Component({

selector:'courses',
template:'<h3>I am DhineshKuamr<h3>'

})
export class CoursesComponent{



}